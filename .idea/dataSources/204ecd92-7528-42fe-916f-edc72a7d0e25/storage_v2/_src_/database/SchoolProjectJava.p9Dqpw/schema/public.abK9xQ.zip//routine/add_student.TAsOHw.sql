create function add_student(in_ime character varying, in_priimek character varying, in_stars_id integer)
  returns integer
language plpgsql
as $$
DECLARE
error integer;
BEGIN
IF ((in_ime IN (SELECT ime FROM Ucenci))AND(in_priimek IN (SELECT priimek FROM Ucenci))AND(in_stars_id IN (SELECT stars_id FROM Ucenci)))THEN
error := 1;
ELSE
INSERT INTO Ucenci(ime,priimek,stars_id)
VALUES (in_ime, in_priimek,in_stars_id);
IF EXISTS(SELECT * FROM Ucenci where((ime like in_ime)AND(in_priimek IN (SELECT priimek FROM Ucenci))AND(in_stars_id IN (SELECT stars_id FROM Ucenci)))) THEN
error := 0;
ELSE
error := 3;
END IF;
END IF;
RETURN error;
END
$$;

