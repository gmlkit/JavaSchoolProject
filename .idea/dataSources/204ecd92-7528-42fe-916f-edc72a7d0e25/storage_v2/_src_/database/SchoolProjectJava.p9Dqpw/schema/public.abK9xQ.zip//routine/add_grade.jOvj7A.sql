create function add_grade(in_ocena integer, in_opisna_ocena character varying, in_opis_ocene character varying, in_predmet_id integer, in_ucenec_id integer)
  returns integer
language plpgsql
as $$
DECLARE
error integer;
ucenec_predmet integer;
BEGIN
IF(in_ime IN (SELECT ime FROM predmeti))THEN
error := 1;
ELSE
IF EXISTS(SELECT id FROM ucenci_predmeti WHERE ucenec_id=in_ucenec_id AND predmet_id=in_predmet_id)
THEN
ucenec_predmet=(SELECT id FROM ucenci_predmeti WHERE ucenec_id=in_ucenec_id AND predmet_id=in_predmet_id);
ELSE
INSERT INTO ucenci_predmeti(ucencec_id,predmet_id)
VALUES (in_ucenec_id,in_predmet_id);
ucenec_predmet=(SELECT id FROM ucenci_predmeti WHERE ucenec_id=in_ucenec_id AND predmet_id=in_predmet_id);
INSERT INTO ocene(ocena,opis_ocene,opisna_ocena,ucenec_predmet_id)
VALUES (in_ocena,in_opis_ocene,in_opisna_ocena,ucenec_predmet);
IF EXISTS(SELECT * FROM ocene WHERE ((ocena=in_ocena) AND (ucenec_predmet_id=ucenec_predmet) AND (opis_ocene=in_opis_ocene)))
THEN
error := 0;
ELSE
error := 3;
END IF;
END IF;
END IF;
RETURN error;
END
$$;

