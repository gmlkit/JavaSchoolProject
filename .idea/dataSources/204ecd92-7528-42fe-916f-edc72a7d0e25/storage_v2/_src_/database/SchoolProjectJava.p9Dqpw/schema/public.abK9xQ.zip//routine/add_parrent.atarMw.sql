create function add_parrent(in_userlogin character varying, in_pass1 character varying, in_pass2 character varying)
  returns integer
language plpgsql
as $$
DECLARE
error integer;
BEGIN
IF (in_userLogin IN (SELECT userLogin FROM Starsi))THEN
error := 1;
ELSE
IF (in_pass1 NOT LIKE in_pass2)THEN
error := 2;
ELSE
INSERT INTO Starsi(userLogin,password)
VALUES (in_userLogin, in_pass1);
IF EXISTS(SELECT * FROM Starsi where(userLogin like in_userLogin)) THEN
error := 0;
ELSE
error := 3;
END IF;
END IF;
END IF;
RETURN error;
END
$$;

