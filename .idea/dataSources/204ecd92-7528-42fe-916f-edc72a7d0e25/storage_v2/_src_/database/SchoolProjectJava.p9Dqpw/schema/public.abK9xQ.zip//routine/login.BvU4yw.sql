create function login(in_email character varying, in_password character varying)
  returns integer
language plpgsql
as $$
DECLARE
login integer;
BEGIN
IF EXISTS (SELECT * FROM starsi WHERE (email LIKE in_email) AND (password LIKE in_password))THEN
login := 0;
ELSE
IF EXISTS(SELECT * FROM ucitelji WHERE (email = in_email) AND (password = in_password)) THEN
login := 1;
ELSE
login := 2;
END IF;
END IF;
RETURN login;
END
$$;

