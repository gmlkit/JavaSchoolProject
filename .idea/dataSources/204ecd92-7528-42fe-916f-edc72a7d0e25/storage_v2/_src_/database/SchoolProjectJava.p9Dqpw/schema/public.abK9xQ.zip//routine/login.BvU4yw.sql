create function login("_userLogin" character varying, _password character varying)
  returns integer
language plpgsql
as $$
DECLARE
login integer;
BEGIN
IF EXISTS(SELECT * FROM Starsi WHERE userLogin=_userLogin AND password=_password)
THEN login:=1;
ELSE
IF EXISTS(SELECT* FROM Ucitelji WHERE userLogin=_userLogin AND password=_password) 
THEN login:=2;
ELSE login:=0;
END IF;
END IF;
RETURN login;
END
$$;

