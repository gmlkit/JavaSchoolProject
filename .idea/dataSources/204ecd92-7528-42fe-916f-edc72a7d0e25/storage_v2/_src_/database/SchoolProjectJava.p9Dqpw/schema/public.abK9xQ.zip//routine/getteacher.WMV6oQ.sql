create function getteacher(in_email character varying)
  returns integer
language plpgsql
as $$
DECLARE
idd integer;
BEGIN
idd= (SELECT id FROM ucitelji WHERE email LIKE in_email);
END
$$;

