create view usersview as
  SELECT ucitelji.id,
    ucitelji.email
   FROM ucitelji;

