create function prijava(_email character varying, _geslo character varying)
  returns character varying
language plpgsql
as $$
BEGIN
	if(_email = 'cancer' AND _geslo = 'xxx') THEN return 'admin';
    else if(_geslo = (SELECT geslo FROM razredniki WHERE email = _email)) THEN
    	return 'makina';
    else 
    	return 'You are dead to me :*';
    end if;
    end if;
END;
$$;

