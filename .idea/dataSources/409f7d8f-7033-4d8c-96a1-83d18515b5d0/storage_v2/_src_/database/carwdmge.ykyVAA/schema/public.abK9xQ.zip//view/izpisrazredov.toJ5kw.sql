create view izpisrazredov as
  SELECT razredi.ime
   FROM razredi;

