create function vnos_dijakov(_ime character varying, _priimek character varying, _datum_r timestamp without time zone, _email character varying, _naslov character varying, _krajiime character varying, _razred integer)
  returns boolean
language plpgsql
as $$
BEGIN 
if((SELECT email FROM dijaki WHERE email = _email) IS NULL) THEN
INSERT INTO dijaki(ime, priimek, email, kraj_id, datum_r, razred_id) VALUES (_ime, _priimek, _email, (SELECT id FROM mesta WHERE ime = _krajiime), _datum_r, _razred);
	return true;
ELSE
	return false;
END IF;
END

$$;

