create function vnos_razredov(_ime character varying)
  returns void
language plpgsql
as $$
BEGIN
	insert into razredi(ime) VALUES (_ime);
END;
$$;

