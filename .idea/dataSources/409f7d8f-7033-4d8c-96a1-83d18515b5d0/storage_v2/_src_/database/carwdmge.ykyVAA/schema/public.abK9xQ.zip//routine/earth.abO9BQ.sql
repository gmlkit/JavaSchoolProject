create function earth()
  returns double precision
immutable
language sql
as $$
SELECT '6378168'::float8
$$;

