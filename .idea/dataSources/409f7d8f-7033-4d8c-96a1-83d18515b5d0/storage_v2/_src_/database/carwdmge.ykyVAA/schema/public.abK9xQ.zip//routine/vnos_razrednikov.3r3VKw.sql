create function vnos_razrednikov(_ime character varying, _priimek character varying, _email character varying, _geslo character varying, _razred character varying)
  returns boolean
language plpgsql
as $$
BEGIN 
INSERT INTO razredniki(ime, piimek, email, geslo, razred_id) VALUES (_ime, _priimek, _email, _geslo, (SELECT id FROM razredi WHERE ime = _razred));
	return true;
END

$$;

