create function xpath_list(text, text)
  returns text
immutable
strict
language sql
as $$
SELECT xpath_list($1,$2,',')
$$;

